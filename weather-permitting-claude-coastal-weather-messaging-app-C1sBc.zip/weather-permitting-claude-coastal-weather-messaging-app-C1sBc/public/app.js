// ── Weather code lookup ───────────────────────────────────────────────────────
const WX = {
  0:  { e: '☀️',  l: 'Clear sky' },
  1:  { e: '🌤️', l: 'Mainly clear' },
  2:  { e: '⛅',  l: 'Partly cloudy' },
  3:  { e: '☁️',  l: 'Overcast' },
  45: { e: '🌫️', l: 'Foggy' },
  48: { e: '🌫️', l: 'Freezing fog' },
  51: { e: '🌦️', l: 'Light drizzle' },
  53: { e: '🌦️', l: 'Drizzle' },
  55: { e: '🌧️', l: 'Heavy drizzle' },
  61: { e: '🌧️', l: 'Light rain' },
  63: { e: '🌧️', l: 'Rain' },
  65: { e: '🌧️', l: 'Heavy rain' },
  71: { e: '🌨️', l: 'Light snow' },
  73: { e: '🌨️', l: 'Snow' },
  75: { e: '❄️',  l: 'Heavy snow' },
  80: { e: '🌦️', l: 'Light showers' },
  81: { e: '🌦️', l: 'Showers' },
  82: { e: '⛈️',  l: 'Heavy showers' },
  95: { e: '⛈️',  l: 'Thunderstorm' },
};
function wx(code) { return WX[code] || { e: '🌡️', l: 'Unknown' }; }

function compass(deg) {
  return ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round(deg / 45) % 8];
}

// Open-Meteo returns times like "2024-01-15T14:00" in the local timezone.
// Parse just the hour digit from the string — no Date() parsing needed.
function formatHour(isoStr) {
  const h = parseInt(isoStr.slice(11, 13), 10);
  if (h === 0)  return 'Midnight';
  if (h === 12) return 'Noon';
  return h < 12 ? `${h}am` : `${h - 12}pm`;
}

// Find the index of the current hour in the hourly array.
// We compare UK-local ISO strings — safe for BST and GMT.
function currentHourIndex(times) {
  const nowStr = new Date()
    .toLocaleString('sv-SE', { timeZone: 'Europe/London' })
    .slice(0, 16)
    .replace(' ', 'T'); // → "YYYY-MM-DDTHH:MM"
  let idx = 0;
  for (let i = 0; i < times.length; i++) {
    if (times[i] <= nowStr) idx = i;
    else break;
  }
  return idx;
}

// ── DOM refs ──────────────────────────────────────────────────────────────────
const $              = id => document.getElementById(id);
const loadingOverlay = $('loading-overlay');
const loadingMsg     = $('loading-msg');
const errorOverlay   = $('error-overlay');
const errorMsgEl     = $('error-msg');
const retryBtn       = $('retry-btn');
const appEl          = $('app');
const locationNameEl = $('location-name');
const updatedAtEl    = $('updated-at');
const refreshBtn     = $('refresh-btn');
const currentEmojiEl = $('current-emoji');
const currentTempEl  = $('current-temp');
const currentDescEl  = $('current-desc');
const feelsLikeEl    = $('feels-like');
const windStatEl     = $('wind-stat');
const humidityStatEl = $('humidity-stat');
const hourlyScrollEl = $('hourly-scroll');
const marineSectionEl = $('marine-section');
const marineContentEl = $('marine-content');
const queryInput     = $('query-input');
const queryBtn       = $('query-btn');
const queryStatus    = $('query-status');
const queryResponse  = $('query-response');

// ── State ─────────────────────────────────────────────────────────────────────
let userCoords = null;

// ── Overlay helpers ───────────────────────────────────────────────────────────
function showLoading(msg) {
  loadingMsg.textContent = msg;
  loadingOverlay.classList.remove('hidden');
  errorOverlay.classList.add('hidden');
  appEl.classList.add('hidden');
}

function showError(msg) {
  errorMsgEl.textContent = msg;
  errorOverlay.classList.remove('hidden');
  loadingOverlay.classList.add('hidden');
  appEl.classList.add('hidden');
}

function showApp() {
  loadingOverlay.classList.add('hidden');
  errorOverlay.classList.add('hidden');
  appEl.classList.remove('hidden');
}

// ── Data fetching ─────────────────────────────────────────────────────────────
function getLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error(
        'Location access isn\'t available in this browser. Try opening the page in Chrome or Safari.'
      ));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
      err => {
        if (err.code === 1) {
          reject(new Error(
            'Location access was denied. Please allow location in your browser settings, then refresh the page.'
          ));
        } else {
          reject(new Error('Couldn\'t get your location. Please check your settings and try again.'));
        }
      },
      { enableHighAccuracy: true, timeout: 15_000 }
    );
  });
}

async function reverseGeocode(lat, lon) {
  try {
    const res  = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&zoom=12`,
      { headers: { Accept: 'application/json' } }
    );
    const data = await res.json();
    const a    = data.address || {};
    return a.village || a.town || a.suburb || a.city_district || a.city || a.county || 'Your location';
  } catch {
    return 'Your location';
  }
}

async function fetchWeather(lat, lon) {
  const params = new URLSearchParams({
    latitude:  lat,
    longitude: lon,
    current:  'temperature_2m,apparent_temperature,relative_humidity_2m,surface_pressure,' +
              'wind_speed_10m,wind_direction_10m,precipitation,weather_code',
    hourly:   'temperature_2m,precipitation_probability,wind_speed_10m,wind_direction_10m,weather_code',
    forecast_days:      '2',
    temperature_unit:   'celsius',
    wind_speed_unit:    'mph',
    precipitation_unit: 'mm',
    timezone:           'auto',
  });
  const res = await fetch(`https://api.open-meteo.com/v1/forecast?${params}`);
  if (!res.ok) throw new Error('Couldn\'t load the weather forecast. Please try again.');
  return res.json();
}

async function fetchMarine(lat, lon) {
  const params = new URLSearchParams({
    latitude:  lat,
    longitude: lon,
    current:  'wave_height,wave_direction,wave_period',
    timezone: 'auto',
  });
  const res = await fetch(`https://marine-api.open-meteo.com/v1/marine?${params}`);
  if (!res.ok) return null;
  return res.json();
}

// ── Rendering ─────────────────────────────────────────────────────────────────
function renderCurrent(weather) {
  const c = weather.current;
  const w = wx(c.weather_code);

  currentEmojiEl.textContent = w.e;
  currentTempEl.textContent  = `${Math.round(c.temperature_2m)}°C`;
  currentDescEl.textContent  = w.l;
  feelsLikeEl.textContent    = `${Math.round(c.apparent_temperature)}°C`;
  windStatEl.textContent     = `${Math.round(c.wind_speed_10m)} mph ${compass(c.wind_direction_10m)}`;
  humidityStatEl.textContent = `${c.relative_humidity_2m}%`;

  updatedAtEl.textContent = `Updated ${new Date().toLocaleTimeString('en-GB', {
    hour: '2-digit', minute: '2-digit'
  })}`;
}

function renderHourly(weather) {
  const h        = weather.hourly;
  const startIdx = currentHourIndex(h.time);
  const count    = Math.min(12, h.time.length - startIdx);

  hourlyScrollEl.innerHTML = '';

  for (let i = 0; i < count; i++) {
    const idx  = startIdx + i;
    const w    = wx(h.weather_code[idx]);
    const rain = h.precipitation_probability[idx] ?? 0;
    const isNow = i === 0;

    const card = document.createElement('div');
    card.className = `hourly-card${isNow ? ' now' : ''}`;
    card.setAttribute('role', 'listitem');
    card.innerHTML = `
      <div class="h-time">${isNow ? 'Now' : formatHour(h.time[idx])}</div>
      <div class="h-emoji" aria-label="${w.l}">${w.e}</div>
      <div class="h-temp">${Math.round(h.temperature_2m[idx])}°</div>
      <div class="h-rain">${rain}%</div>
      <div class="h-wind">${Math.round(h.wind_speed_10m[idx])} mph</div>
      <div class="rain-track"><div class="rain-fill" style="width:${rain}%"></div></div>
    `;
    hourlyScrollEl.appendChild(card);
  }
}

function renderMarine(marine) {
  if (!marine?.current?.wave_height) {
    marineSectionEl.classList.add('hidden');
    return;
  }
  const m    = marine.current;
  const desc =
    m.wave_height < 0.3 ? 'Calm' :
    m.wave_height < 0.5 ? 'Smooth' :
    m.wave_height < 1.0 ? 'Slight' :
    m.wave_height < 2.0 ? 'Moderate' : 'Rough';

  marineContentEl.innerHTML = `
    <div class="marine-stat">
      <span class="m-val">${m.wave_height.toFixed(1)}m</span>
      <span class="m-label">Waves</span>
      <span class="m-sub">${desc}</span>
    </div>
    <div class="marine-stat">
      <span class="m-val">${Math.round(m.wave_period)}s</span>
      <span class="m-label">Period</span>
    </div>
    <div class="marine-stat">
      <span class="m-val">${compass(m.wave_direction)}</span>
      <span class="m-label">Direction</span>
    </div>
  `;
  marineSectionEl.classList.remove('hidden');
}

// ── Init & refresh ────────────────────────────────────────────────────────────
async function init() {
  showLoading('Getting your location…');

  try {
    userCoords = await getLocation();
  } catch (err) {
    showError(err.message);
    return;
  }

  showLoading('Loading your forecast…');

  try {
    const [locationName, weather, marine] = await Promise.all([
      reverseGeocode(userCoords.lat, userCoords.lon),
      fetchWeather(userCoords.lat, userCoords.lon),
      fetchMarine(userCoords.lat, userCoords.lon).catch(() => null),
    ]);

    locationNameEl.textContent = locationName;
    renderCurrent(weather);
    renderHourly(weather);
    renderMarine(marine);
    showApp();
  } catch (err) {
    showError(err.message || 'Couldn\'t load the forecast. Please try again.');
  }
}

async function refresh() {
  if (!userCoords) { init(); return; }
  refreshBtn.disabled = true;
  showLoading('Refreshing forecast…');
  try {
    const [weather, marine] = await Promise.all([
      fetchWeather(userCoords.lat, userCoords.lon),
      fetchMarine(userCoords.lat, userCoords.lon).catch(() => null),
    ]);
    renderCurrent(weather);
    renderHourly(weather);
    renderMarine(marine);
    showApp();
  } catch (err) {
    showError(err.message || 'Couldn\'t refresh. Please try again.');
  } finally {
    refreshBtn.disabled = false;
  }
}

// ── Query ─────────────────────────────────────────────────────────────────────
function setQueryLoading(msg) {
  queryStatus.innerHTML = `<span class="mini-spin" aria-hidden="true"></span>${msg}`;
  queryResponse.classList.add('hidden');
  queryBtn.disabled    = true;
  queryBtn.textContent = 'Asking…';
}

function clearQueryLoading() {
  queryStatus.innerHTML = '';
  queryBtn.disabled     = false;
  queryBtn.textContent  = 'Ask';
}

async function handleQuery() {
  const query = queryInput.value.trim();
  if (!query) return;

  setQueryLoading('Getting the forecast…');

  const controller = new AbortController();
  const timeout    = setTimeout(() => controller.abort(), 35_000);

  try {
    const res  = await fetch('/api/query', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ query, lat: userCoords.lat, lon: userCoords.lon }),
      signal:  controller.signal,
    });
    const data = await res.json();
    clearQueryLoading();

    if (!res.ok) {
      queryResponse.innerHTML = data.error === 'no_key'
        ? '<p class="q-note">The "Ask" feature isn\'t fully set up yet — an API key is needed. Check back soon!</p>'
        : `<p class="q-error">${data.error || 'Something went wrong. Please try again.'}</p>`;
      queryResponse.classList.remove('hidden');
      return;
    }

    const locHtml = data.location
      ? `<p class="q-location">Forecast for ${data.location}</p>`
      : '';
    queryResponse.innerHTML = `${locHtml}<p>${data.response}</p>`;
    queryResponse.classList.remove('hidden');
    queryResponse.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (err) {
    clearQueryLoading();
    queryResponse.innerHTML = `<p class="q-error">${
      err.name === 'AbortError'
        ? 'That took too long — please try again.'
        : 'Couldn\'t get a response. Please try again.'
    }</p>`;
    queryResponse.classList.remove('hidden');
  } finally {
    clearTimeout(timeout);
  }
}

// ── Events ────────────────────────────────────────────────────────────────────
retryBtn.addEventListener('click', init);
refreshBtn.addEventListener('click', refresh);
queryBtn.addEventListener('click', handleQuery);
queryInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleQuery(); }
});

// ── Start ─────────────────────────────────────────────────────────────────────
init();
